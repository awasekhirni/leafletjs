import { Component, OnInit,ViewChild,ElementRef, AfterViewInit } from '@angular/core';
import * as L from 'leaflet'
import 'mapbox-gl-leaflet';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit,AfterViewInit {

  private map!: L.Map;

  @ViewChild('map')
  private mapContainer!: ElementRef<HTMLElement>;

  constructor() { }

  ngAfterViewInit(): void {
     const myAPIKey = "6874694c37974d90854790bdeb10e2be";
     const mapStyle = "https://maps.geoapify.com/v1/styles/osm-carto/style.json";
     const initialState = {
         long: 77.7945,
         lat: 12.7945,
         zoom: 4
     };

     const map = new L.Map(this.mapContainer.nativeElement).setView(
         [initialState.lat, initialState.long],
         initialState.zoom
     );

     // the attribution is required for the Geoapify Free tariff plan
     map.attributionControl
         .setPrefix("")
         .addAttribution(
             'Powered by <a href="https://www.geoapify.com/" target="_blank">Geoapify</a> | © OpenStreetMap <a href="https://www.openstreetmap.org/copyright" target="_blank">contributors</a>'
     );

     L.mapboxGL({
         style: `${mapStyle}?apiKey=${myAPIKey}`,
         accessToken: "no-token"
     }).addTo(map);
  }

  ngOnInit(): void {
  }

}
