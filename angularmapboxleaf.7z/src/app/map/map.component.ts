import { Component, OnInit,ViewChild,ElementRef,AfterViewInit } from '@angular/core';
import {Map} from 'mapbox-gl';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit,AfterViewInit {

  @ViewChild('map')
  private mapContainer!: ElementRef<HTMLElement>;

  private map!: Map;

  constructor() { }
  ngAfterViewInit(): void {
    const myAPIKey='6874694c37974d90854790bdeb10e2be';
    const mapStyle= 'https://maps.geoapify.com/v1/styles/osm-carto/style.json';
    const initialState={
      lat:12.971599,
      long:77.594563,
      zoom:5
    };

    this.map = new Map({
      container: this.mapContainer.nativeElement,
      style:`${mapStyle}?apiKey=${myAPIKey}`,
      center: [initialState.long,initialState.lat],
      zoom: initialState.zoom

    });
  }

  ngOnInit(): void {
  }

}
