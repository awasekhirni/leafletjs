import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MapComponent } from './map/map.component';
import {icon,Marker} from 'leaflet';

const iconRetinaUrl='assets/leaflet/marker-icon-2x.png';
const iconUrl = 'assets/leaflet/marker-icon.png';
const shadowUrl='assets/leaflet/marker-shadow.png'; 
const iconDefault = icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize:[25,41],
  iconAnchor:[12,41],
  popupAnchor:[1,-34],
  tooltipAnchor:[16,-28],
  shadowSize:[41,41]
});
Marker.prototype.options.icon = iconDefault;


@NgModule({
  declarations: [
    AppComponent,
    MapComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
